package helper;

public class Item {
String tcno,adi;

public Item(String tcno, String adi) {
	super();
	this.tcno = tcno;
	this.adi = adi;
}

public String getTc() {
	return tcno;
}

public void setTc(String tcno) {
	this.tcno= tcno;
}

public String getAd() {
	return adi;
}

public void setAd(String adi) {
	this.adi = adi;
}
public String toString() {
	return adi;
	
}
}
