package helper;

import javax.swing.JOptionPane;

public class Helper {
	public static void showMsg(String str) {
		String msg;
		switch (str) {
		case "fill":
			msg = "L�tfen t�m alanlar� doldurunuz.";
			break;
		case "success":
			msg = "��lem ba�ar�l�";
			break;
		case "hata":	
			msg="�ifreniz veya kullan�c� ad�n�z hatal�.";
			break;
		case "sifre":
			msg="TC'niz hatal�d�r. Bu i�lemi ger�ekle�tiremezsiniz.";
			break;
		case "ayn�":
			msg="L�tfen �ifrelerinizi ayn� giriniz.";
			break;
		default:
			msg = str;
		}
		JOptionPane.showMessageDialog(null, msg, "Mesaj", JOptionPane.INFORMATION_MESSAGE);
	}

	public static boolean confirm(String str) {
		String msg;
		switch (str) {
		case "sure":
			msg = "Bu i�lemi ger�ekle�tirmek istiyor musun ?";
			break;
		default:
			msg = str;
			break;

		}
		int res = JOptionPane.showConfirmDialog(null, msg, "Dikkat! ", JOptionPane.YES_NO_OPTION);
       if(res==0) {
    	   return true;
       }
       else {
    	   return false;
       }
	}
}
