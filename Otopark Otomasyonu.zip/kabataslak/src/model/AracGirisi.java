package model;

public class AracGirisi extends MusteriIslemleri {
	protected String konum;

	protected String getKonum() {
		return konum;
	}

	protected void setKonum(String konum) {
		this.konum = konum;
	}

	public AracGirisi(String tc, String adi, String soyadi, String cepTelefonu, String plakaNo, String marka,
			String model, String renk, String sifre, String sifretekrari, String gizliSoru, String yaniti,
			String konum) {
		super(tc, adi, soyadi, cepTelefonu, plakaNo, marka, model, renk, sifre, sifretekrari, gizliSoru, yaniti);
		this.konum = konum;
	}

}
