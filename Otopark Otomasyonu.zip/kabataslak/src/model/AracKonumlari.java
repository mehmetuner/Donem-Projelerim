package model;

import java.util.Scanner;

public class AracKonumlari extends PersonelMenu {
	int a;
	int b;
	int[][] konum;

	public AracKonumlari(int a, int b) {
		super();
		this.a = a;
		this.b = b;
		while (konum[a][b] == 1) {
			System.out.println("dolu");
			Scanner ab = new Scanner(System.in);
			a = ab.nextInt();
			b = ab.nextInt();

		}
		System.out.println("arac�n�z yerle�ti");

	}

}
