package model;

public class PersonelMenu extends PersonelGirisi{

}
