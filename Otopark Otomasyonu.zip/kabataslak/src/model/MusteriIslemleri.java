package model;

public class MusteriIslemleri extends PersonelMenu {
	protected String tc, adi, soyadi, cepTelefonu, plakaNo, marka, model, renk, sifre, sifretekrari, gizliSoru, yaniti;

	protected String getTc() {
		return tc;
	}

	protected void setTc(String tc) {
		this.tc = tc;
	}

	protected String getAdi() {
		return adi;
	}

	protected void setAdi(String adi) {
		this.adi = adi;
	}

	protected String getSoyadi() {
		return soyadi;
	}

	protected void setSoyadi(String soyadi) {
		this.soyadi = soyadi;
	}

	protected String getCepTelefonu() {
		return cepTelefonu;
	}

	protected void setCepTelefonu(String cepTelefonu) {
		this.cepTelefonu = cepTelefonu;
	}

	protected String getPlakaNo() {
		return plakaNo;
	}

	protected void setPlakaNo(String plakaNo) {
		this.plakaNo = plakaNo;
	}

	protected String getMarka() {
		return marka;
	}

	protected void setMarka(String marka) {
		this.marka = marka;
	}

	protected String getModel() {
		return model;
	}

	protected void setModel(String model) {
		this.model = model;
	}

	protected String getRenk() {
		return renk;
	}

	protected void setRenk(String renk) {
		this.renk = renk;
	}

	protected String getSifre() {
		return sifre;
	}

	protected void setSifre(String sifre) {
		this.sifre = sifre;
	}

	protected String getSifretekrari() {
		return sifretekrari;
	}

	protected void setSifretekrari(String sifretekrari) {
		this.sifretekrari = sifretekrari;
	}

	protected String getGizliSoru() {
		return gizliSoru;
	}

	protected void setGizliSoru(String gizliSoru) {
		this.gizliSoru = gizliSoru;
	}

	protected String getYaniti() {
		return yaniti;
	}

	protected void setYaniti(String yaniti) {
		this.yaniti = yaniti;
	}

	public MusteriIslemleri(String tc, String adi, String soyadi, String cepTelefonu, String plakaNo, String marka,
			String model, String renk, String sifre, String sifretekrari, String gizliSoru, String yaniti) {
		super();
		this.tc = tc;
		this.adi = adi;
		this.soyadi = soyadi;
		this.cepTelefonu = cepTelefonu;
		this.plakaNo = plakaNo;
		this.marka = marka;
		this.model = model;
		this.renk = renk;
		this.sifre = sifre;
		this.sifretekrari = sifretekrari;
		this.gizliSoru = gizliSoru;
		this.yaniti = yaniti;
	}

}
