package model;

public class AracCikisi {
  
}
