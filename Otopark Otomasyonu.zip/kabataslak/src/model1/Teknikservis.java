package model1;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Teknikservis extends User {
	PreparedStatement preparedStatement = null;
	Statement st = null;
	ResultSet rs = null;
	Connection con = conn.connDb();
	public Teknikservis(String tcno, String sifre, String type) {
		super(tcno, sifre, type);
	}
   public Teknikservis() {
	   
   }	
   public boolean update(String tcno,String sifre) {
		String query =  "UPDATE teknikgiris SET tcno = ? , sifre = ? WHERE tcno= ?";
		boolean key = false;
		try {
			st = con.createStatement();
			preparedStatement = con.prepareStatement(query);
			preparedStatement.setString(1,tcno);
			preparedStatement.setString(2,sifre);
			preparedStatement.setString(3,tcno);
			
			preparedStatement.executeUpdate();
			key = true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (key) {
			return true;
		} else {
			return false;
		}

	}
}
