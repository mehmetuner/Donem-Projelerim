package model1;

import java.sql.Connection;

import view.*;
import model1.*;
import helper.*;
import java.sql.Connection;


import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
public class Satis1 extends User{
	PreparedStatement preparedStatement = null;
	Statement st = null;
	ResultSet rs = null;
	String plaka;
	int giris, cikis, �cret,tutar;
	Connection con = conn.connDb();

	public Satis1(String plaka, int giris, int cikis, int �cret,int tutar) {
		this.plaka = plaka;
		this.giris = giris;
		this.cikis = cikis;
		this.�cret = �cret;
		this.tutar=tutar;
	}

	public int getTutar() {
		return tutar;
	}

	public void setTutar(int tutar) {
		this.tutar = tutar;
	}

	public Satis1() {

	}

	public String getPlaka() {
		return plaka;
	}

	public void setPlaka(String plaka) {
		this.plaka = plaka;
	}

	public int getGiris() {
		return giris;
	}

	public void setGiris(int giris) {
		this.giris = giris;
	}

	public int getCikis() {
		return cikis;
	}

	public void setCikis(int cikis) {
		this.cikis = cikis;
	}

	public int get�cret() {
		return �cret;
	}

	public void get�cret(int �cret) {
		this.�cret = �cret;
	}

	public ArrayList<Satis1> getList() {
		ArrayList<Satis1> list = new ArrayList<>();
		Connection con = conn.connDb();
		Satis1 obj;
		try {
			st = con.createStatement();
			rs = st.executeQuery("SELECT * FROM satis�slemleri WHERE type='T'");
			while (rs.next()) {
				obj = new Satis1(rs.getString("plaka"), rs.getInt("giris"), rs.getInt("cikis"), rs.getInt("�cret"),rs.getInt("tutar"));
				list.add(obj);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;

	}

	public boolean add(String plaka, int giris, int cikis, int �cret) {
		String query = "INSERT INTO satis�slemleri" + "(plaka,giris,cikis,�cret) VALUES" + "(?,?,?,?)";
		boolean key = false;
		try {
			st = con.createStatement();
			preparedStatement = con.prepareStatement(query);
			preparedStatement.setString(1, plaka);
			preparedStatement.setInt(2, giris);
			preparedStatement.setInt(3, cikis);
			preparedStatement.setInt(4,�cret);

			preparedStatement.executeUpdate();
			key = true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (key) {
			return true;
		} else {
			return false;
		}

	}

	public boolean update(String plaka, int giris, int cikis, int tutar) {
		String query = "UPDATE satis�slemleri SET plaka = ? , giris = ? , cikis = ? , tutar = ? WHERE plaka= ?";
		boolean key = false;
		try {
			st = con.createStatement();
			preparedStatement = con.prepareStatement(query);
			preparedStatement.setString(1, plaka);
			preparedStatement.setInt(2, giris);
			preparedStatement.setInt(3, cikis);
			preparedStatement.setInt(4, tutar);
			preparedStatement.setString(5, plaka);
			preparedStatement.executeUpdate();
			key = true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (key) {
			return true;
		} else {
			return false;
		}

	}

}
