package model1;

import java.sql.Connection;


import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class Personel�slemleri extends User {
	String tcno, cinsiyet, adSoyad, telefon, dogumtarihi, gorevi;
	PreparedStatement preparedStatement = null;
	Statement st = null;
	ResultSet rs = null;
	Connection con = conn.connDb();

	public Personel�slemleri() {

	}

	public Personel�slemleri(String tcno, String cinsiyet, String adSoyad, String telefon, String dogumtarihi,
			String gorevi) {
		super();
		this.tcno = tcno;
		this.cinsiyet = cinsiyet;
		this.adSoyad = adSoyad;
		this.telefon = telefon;
		this.dogumtarihi = dogumtarihi;
		this.gorevi = gorevi;

	}

	public String getTcno() {
		return tcno;
	}

	public void setTcno(String tcno) {
		this.tcno = tcno;
	}

	public String getCinsiyet() {
		return cinsiyet;
	}

	public void setCinsiyet(String cinsiyet) {
		this.cinsiyet = cinsiyet;
	}

	public String getAdSoyad() {
		return adSoyad;
	}

	public void setAdSoyad(String adSoyad) {
		this.adSoyad = adSoyad;
	}

	public String getTelefon() {
		return telefon;
	}

	public void setTelefon(String telefon) {
		this.telefon = telefon;
	}

	public String getDogumtarihi() {
		return dogumtarihi;
	}

	public void setDogumtarihi(String dogumtarihi) {
		this.dogumtarihi = dogumtarihi;
	}

	public String getGorevi() {
		return gorevi;
	}

	public void setGorevi(String gorevi) {
		this.gorevi = gorevi;
	}

	public ArrayList<Personel�slemleri> getList() {
		ArrayList<Personel�slemleri> list = new ArrayList<>();
		Connection con = conn.connDb();
		Personel�slemleri obj;
		try {
			st = con.createStatement();
			rs = st.executeQuery("SELECT * FROM teknikbilgileri WHERE type='T'");
			while (rs.next()) {
				obj = new Personel�slemleri(rs.getString("tcno"), rs.getString("cinsiyet"), rs.getString("adSoyad"),
						rs.getString("telefon"), rs.getString("dogumtarihi"), rs.getString("gorevi"));
				list.add(obj);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;

	}

	public boolean add(String tcno, String adSoyad, String cinsiyet, String telefon, String dogumtarihi,
			String gorevi) {
		String query = "INSERT INTO teknikbilgileri" + "(tcno,adSoyad,cinsiyet,telefon,dogumtarihi,gorevi) VALUES"
				+ "(?,?,?,?,?,?)";
		boolean key = false;
		try {
			st = con.createStatement();
			preparedStatement = con.prepareStatement(query);
			preparedStatement.setString(1, tcno);
			preparedStatement.setString(2, adSoyad);
			preparedStatement.setString(3, cinsiyet);
			preparedStatement.setString(4, telefon);
			preparedStatement.setString(5, dogumtarihi);
			preparedStatement.setString(6, gorevi);
			preparedStatement.executeUpdate();
			key = true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (key) {
			return true;
		} else {
			return false;
		}
	}

	public boolean delete(String tcno) {
		String query = "DELETE FROM teknikbilgileri WHERE tcno = ?";
		boolean key = false;
		try {
			st = con.createStatement();
			preparedStatement = con.prepareStatement(query);
			preparedStatement.setString(1, tcno);
			preparedStatement.executeUpdate();
			key = true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (key) {
			return true;
		} else {
			return false;
		}

	}

	public boolean update(String tcno, String adSoyad, String cinsiyet, String telefon, String dogumtarihi,
			String gorevi) {
		String query = "UPDATE teknikbilgileri SET tcno = ? , adSoyad = ? , cinsiyet = ? , telefon = ? , dogumtarihi = ? , gorevi = ? WHERE tcno= ?";
		boolean key = false;
		try {
			st = con.createStatement();
			preparedStatement = con.prepareStatement(query);
			preparedStatement.setString(1, tcno);
			preparedStatement.setString(2, adSoyad);
			preparedStatement.setString(3, cinsiyet);
			preparedStatement.setString(4, telefon);
			preparedStatement.setString(5, dogumtarihi);
			preparedStatement.setString(6, gorevi);
			preparedStatement.setString(7, tcno);

			preparedStatement.executeUpdate();
			key = true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (key) {
			return true;
		} else {
			return false;
		}

	}

}