package model1;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class M�steriGirisi extends User {
	PreparedStatement preparedStatement = null;
	Statement st = null;
	ResultSet rs = null;
	Connection con = conn.connDb();
	String tcno, adi, soyadi, telefon, plakano, marka, model, renk, konum;

	public M�steriGirisi(String tcno, String adi, String soyadi, String telefon, String plakano, String marka,
			String model, String renk) {
		super();
		this.tcno = tcno;
		this.adi = adi;
		this.soyadi = soyadi;
		this.telefon = telefon;
		this.plakano = plakano;
		this.marka = marka;
		this.model = model;
		this.renk = renk;
	}

	public M�steriGirisi() {

	}

	public ArrayList<M�steriGirisi> getList() {
		ArrayList<M�steriGirisi> list = new ArrayList<>();
		Connection con = conn.connDb();
		M�steriGirisi obj;
		try {
			st = con.createStatement();
			rs = st.executeQuery("SELECT * FROM m�steribilgisi WHERE type='M'");
			while (rs.next()) {
				obj = new M�steriGirisi(rs.getString("tcno"), rs.getString("adi"), rs.getString("soyadi"),
						rs.getString("telefon"), rs.getString("plakano"), rs.getString("marka"), rs.getString("model"),
						rs.getString("renk"));
				list.add(obj);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;

	}

	public boolean add(String tcno, String adi, String soyadi, String telefon, String plakano, String marka,
			String model, String renk) {
		String query = "INSERT INTO m�steribilgisi"
				+ "(tcno,adi,soyadi,telefon,plakano,marka,model,renk) VALUES" + "(?,?,?,?,?,?,?,?)";
		boolean key = false;
		try {
			st = con.createStatement();
			preparedStatement = con.prepareStatement(query);
			preparedStatement.setString(1, tcno);
			preparedStatement.setString(2, adi);
			preparedStatement.setString(3, soyadi);
			preparedStatement.setString(4, telefon);
			preparedStatement.setString(5, plakano);
			preparedStatement.setString(6, marka);
			preparedStatement.setString(7, model);
			preparedStatement.setString(8, renk);
		//	preparedStatement.setString(9, konum);
			preparedStatement.executeUpdate();
			key = true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (key) {
			return true;
		} else {
			return false;
		}

	}
}
