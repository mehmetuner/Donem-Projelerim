package model1;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Cikar extends User {
String plakano,konum;

PreparedStatement preparedStatement = null;
Statement st = null;
ResultSet rs = null;
Connection con = conn.connDb();
public Cikar() {
	
}

public String getPlakano() {
	return plakano;
}

public void setPlakano(String plakano) {
	this.plakano = plakano;
}

public String getKonum() {
	return konum;
}

public void setKonum(String konum) {
	this.konum = konum;
}

public Cikar(String plakano, String konum) {
	super();
	this.plakano = plakano;
	this.konum = konum;
}
public boolean update(String plakano) {
	String query = "UPDATE m�steribilgisi SET konum = 0 WHERE plakano= ?";
	boolean key = false;
	try {
		st = con.createStatement();
		preparedStatement = con.prepareStatement(query);
		preparedStatement.setString(1,plakano);	
	//	preparedStatement.setString(2,plakano);
		preparedStatement.executeUpdate();
		key = true;
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	if (key) {
		return true;
	} else {
		return false;
	}
}
}
