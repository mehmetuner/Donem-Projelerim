package model1;

import helper.DBConnection;

public class User {
	DBConnection conn = new DBConnection();

	public String getTcno() {
		return tcno;
	}

	public void setTcno(String tcno) {
		this.tcno = tcno;
	}

	public String getSifre() {
		return sifre;
	}

	public void setSifre(String sifre) {
		this.sifre = sifre;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public User(String tcno, String sifre, String type) {
		this.tcno = tcno;
		this.sifre = sifre;
		this.type = type;
	}

	public User() {

	}

	String tcno, sifre, type;

}
