package model1;

import java.sql.Connection;


import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class M�steriIslemleri extends User {

	PreparedStatement preparedStatement = null;
	Statement st = null;
	ResultSet rs = null;
	String tcno, adi, soyadi, telefon, plakano, marka, model, renk, konum;
	int id;
	Connection con = conn.connDb();

	public M�steriIslemleri(String tcno, String adi, String soyadi, String telefon, String plakano, String marka,
			String model, String renk, String konum) {
		super();
		this.tcno = tcno;
		this.adi = adi;
		this.soyadi = soyadi;
		this.telefon = telefon;
		this.plakano = plakano;
		this.marka = marka;
		this.model = model;
		this.renk = renk;
		this.konum = konum;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTcno() {
		return tcno;
	}

	public void setTcno(String tcno) {
		this.tcno = tcno;
	}

	public String getAdi() {
		return adi;
	}

	public void setAdi(String adi) {
		this.adi = adi;
	}

	public String getSoyadi() {
		return soyadi;
	}

	public void setSoyadi(String soyadi) {
		this.soyadi = soyadi;
	}

	public String getTelefon() {
		return telefon;
	}

	public void setTelefon(String telefon) {
		this.telefon = telefon;
	}

	public String getPlakano() {
		return plakano;
	}

	public void setPlakano(String plakano) {
		this.plakano = plakano;
	}

	public String getMarka() {
		return marka;
	}

	public void setMarka(String marka) {
		this.marka = marka;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getRenk() {
		return renk;
	}

	public void setRenk(String renk) {
		this.renk = renk;
	}

	public String getKonum() {
		return konum;
	}

	public void setKonum(String konum) {
		this.konum = konum;
	}

	public M�steriIslemleri() {

	}

	public ArrayList<M�steriIslemleri> getList() {
		ArrayList<M�steriIslemleri> list = new ArrayList<>();
		Connection con = conn.connDb();
		M�steriIslemleri obj;
		try {
			st = con.createStatement();
			rs = st.executeQuery("SELECT * FROM m�steribilgisi WHERE type='M'");
			while (rs.next()) {
				obj = new M�steriIslemleri(rs.getString("tcno"), rs.getString("adi"), rs.getString("soyadi"),
						rs.getString("telefon"), rs.getString("plakano"), rs.getString("marka"), rs.getString("model"),
						rs.getString("renk"), rs.getString("konum"));
				list.add(obj);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;

	}

	public boolean add(String tcno, String adi, String soyadi, String telefon, String plakano, String marka,
			String model, String renk, String konum) {
		String query = "INSERT INTO m�steribilgisi"
				+ "(tcno,adi,soyadi,telefon,plakano,marka,model,renk,konum) VALUES" + "(?,?,?,?,?,?,?,?,?)";
		boolean key = false;
		try {
			st = con.createStatement();
			preparedStatement = con.prepareStatement(query);
			preparedStatement.setString(1, tcno);
			preparedStatement.setString(2, adi);
			preparedStatement.setString(3, soyadi);
			preparedStatement.setString(4, telefon);
			preparedStatement.setString(5, plakano);
			preparedStatement.setString(6, marka);
			preparedStatement.setString(7, model);
			preparedStatement.setString(8, renk);
			preparedStatement.setString(9, konum);
			preparedStatement.executeUpdate();
			key = true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (key) {
			return true;
		} else {
			return false;
		}

	}

	public boolean delete(String tcno) {
		String query = "DELETE FROM m�steribilgisi WHERE tcno = ?";
		boolean key = false;
		try {
			st = con.createStatement();
			preparedStatement = con.prepareStatement(query);
			preparedStatement.setString(1,tcno);
			preparedStatement.executeUpdate();
			key = true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (key) {
			return true;
		} else {
			return false;
		}

	}
	public boolean update(String tcno,String adi,String soyadi,String telefon) {
		String query = "UPDATE m�steribilgisi SET tcno = ? , adi = ? , soyadi = ? , telefon = ? WHERE tcno= ?";
		boolean key = false;
		try {
			st = con.createStatement();
			preparedStatement = con.prepareStatement(query);
			preparedStatement.setString(1, tcno);
			preparedStatement.setString(2, adi);
			preparedStatement.setString(3, soyadi);
			preparedStatement.setString(4, telefon);
			preparedStatement.setString(5,tcno);
			preparedStatement.executeUpdate();
			key = true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (key) {
			return true;
		} else {
			return false;
		}

	}
}
