package view;

import java.awt.BorderLayout;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.awt.Color;
import java.awt.Toolkit;
import java.awt.Window.Type;
import javax.swing.JTextPane;
import javax.swing.JTextField;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.ImageIcon;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.JButton;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import javax.swing.JFormattedTextField;
import javax.swing.JMenu;
import javax.swing.JLabel;
import javax.swing.JTabbedPane;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;
import helper.*;
import model1.*;

public class Odev extends JFrame {
	private JTextField txtOtoparkOtomasyonunaHogeldiniz;
	private JTextField musteritc;
	private JTextField Personelfield;
	private JTextField teknik;
	private JPasswordField PersonelPassword;
	private DBConnection conn = new DBConnection();
	private JPasswordField musterisifre;
	private JPasswordField passwordField_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {

		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Odev frame = new Odev();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Odev() {
		getContentPane().setBackground(Color.WHITE);
		setType(Type.UTILITY);
		setIconImage(Toolkit.getDefaultToolkit()
				.getImage("C:\\Users\\mehme\\Desktop\\Yeni klas\u00F6r\\2020-11-19 (1).png"));
		setForeground(Color.MAGENTA);
		setTitle("Otopark Otomasyonu");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 736, 505);
		getContentPane().setLayout(null);

		JMenuItem mn�tmNewMenuItem = new JMenuItem("New menu item");
		mn�tmNewMenuItem.setIcon(new ImageIcon("C:\\Users\\mehme\\Desktop\\arababoyamasayfasi-1503176669gk48n.gif"));
		mn�tmNewMenuItem.setBounds(91, 11, 557, 265);
		getContentPane().add(mn�tmNewMenuItem);

		txtOtoparkOtomasyonunaHogeldiniz = new JTextField();
		txtOtoparkOtomasyonunaHogeldiniz.setBackground(Color.WHITE);
		txtOtoparkOtomasyonunaHogeldiniz.setFont(new Font("Arial Black", Font.PLAIN, 15));
		txtOtoparkOtomasyonunaHogeldiniz.setEditable(false);
		txtOtoparkOtomasyonunaHogeldiniz.setForeground(Color.MAGENTA);
		txtOtoparkOtomasyonunaHogeldiniz.setText("Otopark Otomasyonuna Ho\u015Fgeldiniz.");
		txtOtoparkOtomasyonunaHogeldiniz.setBounds(179, 299, 369, 37);
		getContentPane().add(txtOtoparkOtomasyonunaHogeldiniz);
		txtOtoparkOtomasyonunaHogeldiniz.setColumns(12);

		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBackground(Color.WHITE);
		tabbedPane.setBounds(179, 347, 369, 108);
		getContentPane().add(tabbedPane);

		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setToolTipText("");
		tabbedPane.addTab("M��teri Giri�i", null, panel, null);
		panel.setLayout(null);

		JLabel lblNewLabel = new JLabel("Tc:");
		lblNewLabel.setFont(new Font("Arial Black", Font.PLAIN, 18));
		lblNewLabel.setBounds(22, 0, 41, 39);
		panel.add(lblNewLabel);

		musteritc = new JTextField();
		musteritc.setBounds(77, 12, 146, 20);
		panel.add(musteritc);
		musteritc.setColumns(10);

		JLabel lblSifre = new JLabel("Sifre");
		lblSifre.setFont(new Font("Arial Black", Font.PLAIN, 18));
		lblSifre.setBounds(10, 30, 53, 39);
		panel.add(lblSifre);

		JButton btnNewButton = new JButton("Giri\u015F Yap");
		btnNewButton.setBackground(Color.WHITE);
		btnNewButton.addActionListener(new ActionListener() {
			@SuppressWarnings("deprecation")
			public void actionPerformed(ActionEvent e) {

				if (musteritc.getText().length() == 0 || musterisifre.getText().length() == 0) {
					Helper.showMsg("fill");
				} else {
                     		
					try {
						Connection con = conn.connDb();
						Statement st = con.createStatement();
						ResultSet rs = st.executeQuery("Select * from musteri");
						while (rs.next()) {
							if (musteritc.getText().equals(rs.getString("tcno"))
									&& musterisifre.getText().equals(rs.getString("sifre"))) {
								M�steriGirisi mg = new M�steriGirisi();
								mg.setTcno(rs.getString("tcno"));
								mg.setSifre(rs.getString("sifre"));
								mg.setType(rs.getString("type"));
								Odev3 m�steri = new Odev3(mg);
								m�steri.setVisible(true);
								dispose();
								

							}

						}
						boolean hata=false;
						try {
							 rs = st.executeQuery("Select * from musteri");
							while(rs.next()) {
								if(musteritc.getText().equals(rs.getString("tcno")) && musterisifre.getText().equals(rs.getString("sifre"))) {
									//Helper.showMsg("hata");
									hata=true;
									break;
								}
							}
							
						}catch(SQLException e1) {
							e1.printStackTrace();
						}
						if(!hata) {
							Helper.showMsg("hata");
						}
					}catch (SQLException e1) {
						e1.printStackTrace();
					}
					

				}
			}
		});
		btnNewButton.setBounds(254, 12, 100, 31);
		panel.add(btnNewButton);

		musterisifre = new JPasswordField();
		musterisifre.setBounds(77, 42, 146, 20);
		panel.add(musterisifre);

		JButton btnifremiUnuttum_1_1 = new JButton("\u015Fifremi unuttum");
		btnifremiUnuttum_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SifremiUnuttum.main(null);
				dispose();
			}
		});
		btnifremiUnuttum_1_1.setBackground(Color.WHITE);
		btnifremiUnuttum_1_1.setBounds(233, 46, 131, 23);
		panel.add(btnifremiUnuttum_1_1);

		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.WHITE);
		tabbedPane.addTab("Personel Giri�i", null, panel_1, null);
		panel_1.setLayout(null);

		JLabel lblNewLabel_1 = new JLabel("Tc:");
		lblNewLabel_1.setBounds(21, 2, 31, 26);
		lblNewLabel_1.setFont(new Font("Arial Black", Font.PLAIN, 18));
		panel_1.add(lblNewLabel_1);

		Personelfield = new JTextField();
		Personelfield.setBounds(83, 8, 162, 20);
		Personelfield.setColumns(10);
		panel_1.add(Personelfield);

		JLabel lblSifre_1 = new JLabel("Sifre: ");
		lblSifre_1.setBounds(10, 43, 70, 26);
		panel_1.add(lblSifre_1);
		lblSifre_1.setFont(new Font("Arial Black", Font.PLAIN, 18));

		JButton btnNewButton_1 = new JButton("Giri\u015F Yap");
		btnNewButton_1.setBackground(Color.WHITE);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				if (Personelfield.getText().length() == 0 || PersonelPassword.getText().length() == 0) {
					Helper.showMsg("fill");
				} else {

					try {
						Connection con = conn.connDb();
						Statement st = con.createStatement();
						ResultSet rs = st.executeQuery("Select * from personelgirisi");
						while (rs.next()) {
							if (Personelfield.getText().equals(rs.getString("tcno"))
									&& PersonelPassword.getText().equals(rs.getString("sifre"))) {
								Personel1 pe = new Personel1();
								pe.setTcno(rs.getString("tcno"));
								pe.setSifre(rs.getString("sifre"));
								pe.setType(rs.getString("type"));
								Odev1 personel = new Odev1(pe);
								personel.setVisible(true);
								dispose();

							}
						}

						boolean hata=false;
						try {
							 rs = st.executeQuery("Select * from personelgirisi");
							while(rs.next()) {
								if(Personelfield.getText().equals(rs.getString("tcno")) && PersonelPassword.getText().equals(rs.getString("sifre"))) {
									//Helper.showMsg("hata");
									hata=true;
									break;
								}
							}
							
						}catch(SQLException e1) {
							e1.printStackTrace();
						}
						if(!hata) {
							Helper.showMsg("hata");
						}
					} catch (SQLException e1) {
						e1.printStackTrace();
					}
				}
			}
		});
		btnNewButton_1.setBounds(255, 11, 89, 23);
		panel_1.add(btnNewButton_1);

		JButton btnifremiUnuttum_1 = new JButton("\u015Fifremi unuttum");
		btnifremiUnuttum_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SifremiUnuttum.main(null);
				dispose();
			}
		});
		btnifremiUnuttum_1.setBackground(Color.WHITE);
		btnifremiUnuttum_1.setBounds(233, 48, 131, 23);
		panel_1.add(btnifremiUnuttum_1);

		PersonelPassword = new JPasswordField();
		PersonelPassword.setBounds(83, 49, 142, 20);
		panel_1.add(PersonelPassword);

		JPanel panel_2 = new JPanel();
		panel_2.setBackground(Color.WHITE);
		tabbedPane.addTab("Teknik Servis", null, panel_2, null);
		panel_2.setLayout(null);

		JLabel lblNewLabel_2 = new JLabel("Tc:");
		lblNewLabel_2.setFont(new Font("Arial Black", Font.PLAIN, 18));
		lblNewLabel_2.setBounds(22, 11, 41, 39);
		panel_2.add(lblNewLabel_2);

		teknik = new JTextField();
		teknik.setColumns(10);
		teknik.setBounds(77, 23, 140, 20);
		panel_2.add(teknik);

		JLabel lblSifre_2 = new JLabel("Sifre");
		lblSifre_2.setFont(new Font("Arial Black", Font.PLAIN, 18));
		lblSifre_2.setBounds(10, 41, 53, 39);
		panel_2.add(lblSifre_2);

		JButton TeknikServisField = new JButton("Giri\u015F Yap");
		TeknikServisField.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (teknik.getText().length() == 0 || passwordField_1.getText().length() == 0) {
					Helper.showMsg("fill");
				} else {

					try {
						Connection con = conn.connDb();
						Statement st = con.createStatement();
						ResultSet rs = st.executeQuery("Select * from teknikgiris");
						while (rs.next()) {
							if (teknik.getText().equals(rs.getString("tcno"))
									&& passwordField_1.getText().equals(rs.getString("sifre"))) {
								Teknikservis te = new Teknikservis();
								te.setTcno(rs.getString("tcno"));
								te.setSifre(rs.getString("sifre"));
								te.setType(rs.getString("type"));
								Teknikservisgirisi Teknikservis = new Teknikservisgirisi(te);
								Teknikservis.setVisible(true);
								dispose();

							}
						}

						boolean hata=false;
						try {
							 rs = st.executeQuery("Select * from teknikgiris");
							while(rs.next()) {
								if(teknik.getText().equals(rs.getString("tcno")) && passwordField_1.getText().equals(rs.getString("sifre"))) {
									//Helper.showMsg("hata");
									hata=true;
									break;
								}
							}
							
						}catch(SQLException e1) {
							e1.printStackTrace();
						}
						if(!hata) {
							Helper.showMsg("hata");
						}
					} catch (SQLException e1) {
						e1.printStackTrace();
					}
				}
			}
		});
		TeknikServisField.setBackground(Color.WHITE);
		TeknikServisField.setBounds(259, 19, 89, 23);
		panel_2.add(TeknikServisField);

		JButton btnifremiUnuttum_2 = new JButton("\u015Fifremi unuttum");
		btnifremiUnuttum_2.setBackground(Color.WHITE);
		btnifremiUnuttum_2.setBounds(227, 51, 131, 23);
		panel_2.add(btnifremiUnuttum_2);

		passwordField_1 = new JPasswordField();
		passwordField_1.setBounds(87, 54, 116, 20);
		panel_2.add(passwordField_1);

	}
}
