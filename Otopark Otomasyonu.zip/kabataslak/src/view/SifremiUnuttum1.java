package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import helper.DBConnection;
import helper.Helper;
import model1.M�steriGirisi;
import model1.Personel1;
import model1.Sifre;

import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;
import java.awt.Font;
import java.awt.Color;

public class SifremiUnuttum1 extends JFrame {

	private JPanel contentPane;
	private JTextField unuttc;
	static Sifre s = new Sifre();
	private DBConnection conn = new DBConnection();
	static Personel1 a = new Personel1();
	private JPasswordField sifre1;
	private JPasswordField sifre2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SifremiUnuttum1 frame = new SifremiUnuttum1(a);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SifremiUnuttum1(Personel1 a) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 596, 376);
		contentPane = new JPanel();
		contentPane.setBackground(Color.CYAN);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblNewLabel = new JLabel("Tc:");
		lblNewLabel.setFont(new Font("Arial Black", Font.PLAIN, 17));
		lblNewLabel.setBounds(54, 81, 46, 17);
		contentPane.add(lblNewLabel);

		unuttc = new JTextField();
		unuttc.setBounds(139, 78, 170, 20);
		contentPane.add(unuttc);
		unuttc.setColumns(10);

		JButton btnNewButton = new JButton("Onay");
		btnNewButton.setBackground(Color.WHITE);
		btnNewButton.setFont(new Font("Arial Black", Font.PLAIN, 12));
		btnNewButton.setForeground(Color.RED);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Statement st;
				try {
					Connection con = conn.connDb();
					st = con.createStatement();
					ResultSet rs = st.executeQuery("Select * from personelgirisi");
					while (rs.next()) {
						if (unuttc.getText().equals(rs.getString("tcno"))) {

							M�steriGirisi mg = new M�steriGirisi();
							mg.setTcno(rs.getString("tcno"));
							mg.setType(rs.getString("type"));
							sifre1.setEditable(true);
							sifre2.setEditable(true);
							if (sifre1.getText().length() == 0 || sifre2.getText().length() == 0) {
								Helper.showMsg("fill");
							}
							else if(!sifre1.getText().equals(sifre2.getText())) {
								Helper.showMsg("ayn�");
							}
							else {
								boolean control = a.update(unuttc.getText(), sifre1.getText());
								if (control) {
									Helper.showMsg("success");
									Odev.main(null);
									dispose();
								}

							}

						}

					}
				 /*catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();*/
				
				try {
				//	Connection con = conn.connDb();
					//st = con.createStatement();
					//ResultSet rs = st.executeQuery("Select * from personelgirisi");
					while (rs.next()) {
						if (unuttc.getText().equals(rs.getString("tcno"))) {
							break;
						}
						if (!unuttc.getText().equals(rs.getString("tcno"))) {
							Helper.showMsg("sifre");
							break;
						}
					}
				} catch (SQLException e1) {
					e1.printStackTrace();
				}

			}catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();}
			}
		});
		btnNewButton.setBounds(350, 100, 89, 33);
		contentPane.add(btnNewButton);

		sifre1 = new JPasswordField();
		sifre1.setEditable(false);
		sifre1.setBounds(139, 140, 170, 20);
		contentPane.add(sifre1);

		sifre2 = new JPasswordField();
		sifre2.setEditable(false);
		sifre2.setBounds(139, 182, 170, 20);
		contentPane.add(sifre2);

		JLabel lblNewLabel_1 = new JLabel("Yeni \u015Fifre");
		lblNewLabel_1.setFont(new Font("Arial Black", Font.PLAIN, 12));
		lblNewLabel_1.setBounds(30, 140, 70, 20);
		contentPane.add(lblNewLabel_1);

		JLabel lblNewLabel_2 = new JLabel("Tekrar");
		lblNewLabel_2.setFont(new Font("Arial Black", Font.PLAIN, 12));
		lblNewLabel_2.setBounds(32, 182, 62, 20);
		contentPane.add(lblNewLabel_2);

		JButton btnNewButton_1 = new JButton("Anasayfa");
		btnNewButton_1.setFont(new Font("Arial Black", Font.PLAIN, 12));
		btnNewButton_1.setForeground(Color.RED);
		btnNewButton_1.setBackground(Color.WHITE);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Odev.main(null);
			}
		});
		btnNewButton_1.setBounds(452, 25, 102, 41);
		contentPane.add(btnNewButton_1);
	}
}
