package view;

import java.awt.BorderLayout;


import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import helper.DBConnection;
import helper.Helper;
import helper.Item;
import model1.Cikar;
import model1.M�steriIslemleri;
import model1.Personel�slemleri;
import model1.User;

import javax.swing.JSplitPane;
import javax.swing.JDesktopPane;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import java.awt.Component;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.swing.JComboBox;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JEditorPane;
import javax.swing.JProgressBar;
import javax.swing.JSeparator;
import javax.swing.JTree;
import javax.swing.JLayeredPane;
import javax.swing.JToolBar;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.ActionEvent;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JScrollPane;


public class Odev2 extends JFrame {
	private DBConnection conn = new DBConnection();
	private JPanel contentPane;
	private JTextField tcno1;
	private JTextField ad1;
	private JTextField soyad1;
	private JTextField cep1;
	private JTextField plaka1;
	private JTextField marka1;
	private JTextField model1;
	private JTextField renk1;
	private JTextField konum1;
	private DefaultTableModel personelModel = null;
	private Object[] personelData = null;
	static M�steriIslemleri m�steri = new M�steriIslemleri();
	static Cikar c=new Cikar();
	static User u = new User();
	Statement st = null;
	ResultSet rs = null;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Odev2 frame = new Odev2();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Odev2() {
		personelModel = new DefaultTableModel();
		Object[] colpersonelName = new Object[4];
		colpersonelName[0] = "tc";
		colpersonelName[1] = "Ad�";
		colpersonelName[2] = "soyad�";
		colpersonelName[3] = "telefon";
		personelModel.setColumnIdentifiers(colpersonelName);
		personelData = new Object[4];
		for (int i = 0; i < m�steri.getList().size(); i++) {
			personelData[0] = m�steri.getList().get(i).getTcno();
			personelData[1] = m�steri.getList().get(i).getAdi();
			personelData[2] = m�steri.getList().get(i).getSoyadi();
			personelData[3] = m�steri.getList().get(i).getTelefon();
			personelModel.addRow(personelData);
		}

		setTitle("Ara\u00E7 Giri\u015Fi");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 917, 487);
		contentPane = new JPanel();
		contentPane.setBackground(Color.CYAN);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JComboBox comboBox = new JComboBox();
		comboBox.setBounds(200, 48, 41, 15);
		

		for (int i = 0; i < m�steri.getList().size(); i++) {
			comboBox.addItem(m�steri.getList().get(i).getTcno());

		}
		comboBox.addItemListener(new ItemListener() {
			
			@Override
			public void itemStateChanged(ItemEvent e) {
				tcno1.setText(m�steri.getList().get(comboBox.getSelectedIndex()).getTcno());
				ad1.setText(m�steri.getList().get(comboBox.getSelectedIndex()).getAdi());
				soyad1.setText(m�steri.getList().get(comboBox.getSelectedIndex()).getSoyadi());
				cep1.setText(m�steri.getList().get(comboBox.getSelectedIndex()).getTelefon());
			    plaka1.setText(m�steri.getList().get(comboBox.getSelectedIndex()).getPlakano());
	            marka1.setText(m�steri.getList().get(comboBox.getSelectedIndex()).getMarka());
              	model1.setText(m�steri.getList().get(comboBox.getSelectedIndex()).getModel());
	            renk1.setText(m�steri.getList().get(comboBox.getSelectedIndex()).getRenk());
	            konum1.setText(m�steri.getList().get(comboBox.getSelectedIndex()).getKonum());
	       
	
			}
		});
	
	
		
		
		
		contentPane.add(comboBox);

		JLabel lblNewLabel = new JLabel("Kay\u0131tl\u0131 M\u00FC\u015Fteri Tc");
		lblNewLabel.setForeground(Color.BLACK);
		lblNewLabel.setFont(new Font("Arial Black", Font.PLAIN, 18));
		lblNewLabel.setBounds(10, 32, 194, 43);
		contentPane.add(lblNewLabel);

		JPanel panel = new JPanel();
		panel.setBackground(Color.YELLOW);
		panel.setBounds(21, 121, 274, 195);
		contentPane.add(panel);
		panel.setLayout(null);

		JLabel lblNewLabel_2 = new JLabel("T.C:");
		lblNewLabel_2.setFont(new Font("Arial Black", Font.PLAIN, 15));
		lblNewLabel_2.setBounds(10, 11, 60, 14);
		panel.add(lblNewLabel_2);

		tcno1 = new JTextField();
		tcno1.setBounds(147, 10, 117, 20);
		panel.add(tcno1);
		tcno1.setColumns(10);

		JLabel lblNewLabel_2_1 = new JLabel("Ad\u0131:");
		lblNewLabel_2_1.setFont(new Font("Arial Black", Font.PLAIN, 15));
		lblNewLabel_2_1.setBounds(10, 52, 60, 14);
		panel.add(lblNewLabel_2_1);

		ad1 = new JTextField();
		ad1.setColumns(10);
		ad1.setBounds(147, 51, 117, 20);
		panel.add(ad1);

		JLabel lblNewLabel_2_1_1 = new JLabel("Soyad\u0131:");
		lblNewLabel_2_1_1.setFont(new Font("Arial Black", Font.PLAIN, 15));
		lblNewLabel_2_1_1.setBounds(10, 92, 60, 14);
		panel.add(lblNewLabel_2_1_1);

		soyad1 = new JTextField();
		soyad1.setColumns(10);
		soyad1.setBounds(147, 91, 117, 20);
		panel.add(soyad1);

		JLabel lblNewLabel_2_1_2 = new JLabel("Cep telefonu:");
		lblNewLabel_2_1_2.setFont(new Font("Arial Black", Font.PLAIN, 15));
		lblNewLabel_2_1_2.setBounds(10, 130, 127, 14);
		panel.add(lblNewLabel_2_1_2);

		cep1 = new JTextField();
		cep1.setColumns(10);
		cep1.setBounds(147, 129, 117, 20);
		panel.add(cep1);

		JLabel lblNewLabel_1 = new JLabel("M\u00FC\u015Fteri Bilgileri");
		lblNewLabel_1.setBounds(24, 101, 97, 22);
		contentPane.add(lblNewLabel_1);

		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.YELLOW);
		panel_1.setLayout(null);
		panel_1.setBounds(393, 121, 274, 195);
		contentPane.add(panel_1);

		JLabel lblNewLabel_2_2 = new JLabel("Plaka no:");
		lblNewLabel_2_2.setFont(new Font("Arial Black", Font.PLAIN, 15));
		lblNewLabel_2_2.setBounds(10, 11, 102, 14);
		panel_1.add(lblNewLabel_2_2);

		plaka1 = new JTextField();
		plaka1.setColumns(10);
		plaka1.setBounds(147, 10, 117, 20);
		panel_1.add(plaka1);

		JLabel lblNewLabel_2_1_3 = new JLabel("Marka:");
		lblNewLabel_2_1_3.setFont(new Font("Arial Black", Font.PLAIN, 15));
		lblNewLabel_2_1_3.setBounds(10, 52, 60, 14);
		panel_1.add(lblNewLabel_2_1_3);

		marka1 = new JTextField();
		marka1.setColumns(10);
		marka1.setBounds(147, 51, 117, 20);
		panel_1.add(marka1);

		JLabel lblNewLabel_2_1_1_1 = new JLabel("Model:");
		lblNewLabel_2_1_1_1.setFont(new Font("Arial Black", Font.PLAIN, 15));
		lblNewLabel_2_1_1_1.setBounds(10, 92, 60, 14);
		panel_1.add(lblNewLabel_2_1_1_1);

		model1 = new JTextField();
		model1.setColumns(10);
		model1.setBounds(147, 91, 117, 20);
		panel_1.add(model1);

		JLabel lblNewLabel_2_1_2_1 = new JLabel("Renk");
		lblNewLabel_2_1_2_1.setFont(new Font("Arial Black", Font.PLAIN, 15));
		lblNewLabel_2_1_2_1.setBounds(10, 130, 127, 14);
		panel_1.add(lblNewLabel_2_1_2_1);

		renk1 = new JTextField();
		renk1.setColumns(10);
		renk1.setBounds(147, 129, 117, 20);
		panel_1.add(renk1);

		JLabel lblNewLabel_2_1_2_1_1 = new JLabel("Konumu:");
		lblNewLabel_2_1_2_1_1.setFont(new Font("Arial Black", Font.PLAIN, 15));
		lblNewLabel_2_1_2_1_1.setBounds(10, 164, 127, 14);
		panel_1.add(lblNewLabel_2_1_2_1_1);

		konum1 = new JTextField();
		konum1.setColumns(10);
		konum1.setBounds(147, 163, 117, 20);
		panel_1.add(konum1);

		JLabel lblNewLabel_1_1 = new JLabel("Ara\u00E7 Bilgileri");
		lblNewLabel_1_1.setBounds(396, 101, 97, 22);
		contentPane.add(lblNewLabel_1_1);

		JButton btnNewButton = new JButton("Men\u00FC");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Odev1.main(null);
				dispose();
			}
		});
		btnNewButton.setBackground(Color.WHITE);
		btnNewButton.setFont(new Font("Arial Black", Font.PLAIN, 18));
		btnNewButton.setBounds(46, 344, 124, 81);
		contentPane.add(btnNewButton);

		JButton btnAraYerleri = new JButton("Ara\u00E7 yerleri");
		btnAraYerleri.setBackground(Color.WHITE);
		btnAraYerleri.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Odev4.main(null);
				dispose();
			}
		});
		btnAraYerleri.setFont(new Font("Arial Black", Font.PLAIN, 18));
		btnAraYerleri.setBounds(200, 344, 149, 81);
		contentPane.add(btnAraYerleri);

		JButton btnAraKaydet = new JButton("Ara\u00E7 Kaydet");
		btnAraKaydet.setBackground(Color.WHITE);
		btnAraKaydet.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				if (tcno1.getText().length() == 0 || ad1.getText().length() == 0 || soyad1.getText().length() == 0
						|| cep1.getText().length() == 0 || plaka1.getText().length() == 0
						|| marka1.getText().length() == 0 || model1.getText().length() == 0
						|| renk1.getText().length() == 0 || konum1.getText().length() == 0) {
					Helper.showMsg("fill");
				} else {
					ArrayList<String> konumlar = new ArrayList<String>();
					for (int i = 0; i < Odev2.m�steri.getList().size(); i++) {
						konumlar.add(Odev2.m�steri.getList().get(i).getKonum());

					}
						boolean control = m�steri.add(tcno1.getText(), ad1.getText(), soyad1.getText(), cep1.getText(),
								plaka1.getText(), marka1.getText(), model1.getText(), renk1.getText(), konum1.getText());
						if (control  ) {
							Helper.showMsg("success");
							for (int i = 0; i < konumlar.size(); i++) {
								 System.out.println(konumlar.get(i));
								if (konum1.getText().equals(konumlar.get(i))) {
									c.update(plaka1.getText());
									String msg="Arac�n�z "+ Odev2.m�steri.getList().get(i).getKonum() + " Konumunda olamaz.";
				                	JOptionPane.showMessageDialog(null, msg, "Mesaj", JOptionPane.INFORMATION_MESSAGE);
									break;
								    
								}
							}
							tcno1.setText(null);
							ad1.setText(null);
							soyad1.setText(null);
							cep1.setText(null);
							plaka1.setText(null);
							marka1.setText(null);
							model1.setText(null);
							renk1.setText(null);
							konum1.setText(null);

						}
						
						
					}
					
									}
			
		});
		btnAraKaydet.setFont(new Font("Arial Black", Font.PLAIN, 18));
		btnAraKaydet.setBounds(377, 344, 163, 81);
		contentPane.add(btnAraKaydet);

		JButton btnProgramdank = new JButton("Programdan \u00C7\u0131k");
		btnProgramdank.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        
			}
		});
		btnProgramdank.setBackground(Color.WHITE);
		btnProgramdank.setFont(new Font("Arial Black", Font.PLAIN, 18));
		btnProgramdank.setBounds(568, 344, 200, 81);
		contentPane.add(btnProgramdank);

		ArrayList<String> konumlar = new ArrayList<String>();
		for (int i = 0; i < Odev2.m�steri.getList().size(); i++) {
			konumlar.add(Odev2.m�steri.getList().get(i).getKonum());

		}
		for (int i = 0; i < konumlar.size(); i++) {
			 System.out.println(konumlar.get(i));
	
	
		}
	}
}
