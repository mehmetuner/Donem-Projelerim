package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import helper.Helper;
import model1.Cikar;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Color;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;

public class AracCikis extends JFrame {

	private JPanel contentPane;
	private JTextField plakacikar;
	static Cikar c=new Cikar();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AracCikis frame = new AracCikis();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AracCikis() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 833, 315);
		contentPane = new JPanel();
		contentPane.setBackground(Color.CYAN);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Hangi arabay\u0131 \u00E7\u0131karmak istiyorsunuz ?");
		lblNewLabel.setFont(new Font("Arial Black", Font.PLAIN, 15));
		lblNewLabel.setForeground(Color.BLACK);
		lblNewLabel.setBounds(10, 38, 358, 74);
		contentPane.add(lblNewLabel);
		
		plakacikar = new JTextField();
		plakacikar.setBounds(366, 58, 249, 54);
		contentPane.add(plakacikar);
		plakacikar.setColumns(10);
		  ArrayList<String> plakalar=new ArrayList<>();
		  for(int i=0; i<Odev2.m�steri.getList().size(); i++) {
		  	plakalar.add(Odev2.m�steri.getList().get(i).getPlakano());
		  }
		JButton btnNewButton = new JButton("\u00C7\u0131kar");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 int index=0;
					for(int i=0; i<plakalar.size(); i++) {
						if(plakalar.get(i).equals(plakacikar.getText())){
						//	System.out.println(plakalar.get(i));
			            	index=i;
			            	//System.out.println(index);
			            }
						
					}
				
             if(plakalar.contains(plakacikar.getText())){
            	  boolean control=c.update(plakacikar.getText());
					if (control) {
						Helper.showMsg("success");
						

					}
             }	
             else {
            		String msg="Arac�n�z Bulunamad�.";
                	JOptionPane.showMessageDialog(null, msg, "Mesaj", JOptionPane.INFORMATION_MESSAGE);
             }
             Odev1.main(null);
             dispose();
			}
		});
		btnNewButton.setFont(new Font("Arial Black", Font.PLAIN, 15));
		btnNewButton.setBounds(654, 66, 116, 39);
		contentPane.add(btnNewButton);
	}
}
