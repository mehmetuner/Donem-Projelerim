package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import helper.DBConnection;
import helper.Helper;
import model1.M�steriGirisi;
import model1.M�steriIslemleri;
import model1.Personel1;

import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.awt.event.ActionEvent;

public class Odev3 extends JFrame {
	private DBConnection conn = new DBConnection();
	private JPanel contentPane;
	static M�steriGirisi mgi = new M�steriGirisi();
	static M�steriIslemleri mi = new M�steriIslemleri();
	Statement st = null;
	ResultSet rs = null;
	private JTextField model1;
	private JTextField renk1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Odev3 frame = new Odev3(mgi);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Odev3(M�steriGirisi mgi) {
		setTitle("Personel \u0130\u015Flemleri");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 690, 700);
		contentPane = new JPanel();
		contentPane.setBackground(Color.CYAN);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel panel = new JPanel();
		panel.setBackground(Color.MAGENTA);
		panel.setForeground(new Color(0, 0, 0));
		panel.setToolTipText("");
		panel.setBounds(0, 0, 387, 650);
		contentPane.add(panel);
		panel.setLayout(null);

		JTextField txtPersonelBilgileri = new JTextField();
		txtPersonelBilgileri.setBackground(Color.WHITE);
		txtPersonelBilgileri.setForeground(Color.BLUE);
		txtPersonelBilgileri.setEditable(false);
		txtPersonelBilgileri.setFont(new Font("Arial Black", Font.PLAIN, 18));
		txtPersonelBilgileri.setText("M\u00FC\u015Fteri Bilgileri");
		txtPersonelBilgileri.setBounds(10, 4, 267, 32);
		panel.add(txtPersonelBilgileri);
		txtPersonelBilgileri.setColumns(10);

		JTextField tcno1 = new JTextField();
		tcno1.setBounds(135, 47, 222, 25);
		panel.add(tcno1);
		tcno1.setColumns(10);

		JTextField ad1 = new JTextField();
		ad1.setColumns(10);
		ad1.setBounds(135, 90, 222, 25);
		panel.add(ad1);

		JTextField soyad1 = new JTextField();
		soyad1.setColumns(10);
		soyad1.setBounds(135, 131, 222, 25);
		panel.add(soyad1);

		JTextField cep1 = new JTextField();
		cep1.setColumns(10);
		cep1.setBounds(135, 175, 222, 25);
		panel.add(cep1);

		JTextField plaka1 = new JTextField();
		plaka1.setColumns(10);
		plaka1.setBounds(135, 217, 222, 25);
		panel.add(plaka1);

		JTextField marka1 = new JTextField();
		marka1.setColumns(10);
		marka1.setBounds(135, 263, 222, 25);
		panel.add(marka1);

		JLabel lblNewLabel = new JLabel("TC:");
		lblNewLabel.setFont(new Font("Arial Black", Font.PLAIN, 12));
		lblNewLabel.setBounds(10, 47, 93, 21);
		panel.add(lblNewLabel);

		JLabel lblAdVeSoyad = new JLabel("Ad\u0131:");
		lblAdVeSoyad.setFont(new Font("Arial Black", Font.PLAIN, 12));
		lblAdVeSoyad.setBounds(10, 94, 93, 21);
		panel.add(lblAdVeSoyad);

		JLabel lblCinsiyet = new JLabel("Soyad\u0131:");
		lblCinsiyet.setFont(new Font("Arial Black", Font.PLAIN, 12));
		lblCinsiyet.setBounds(10, 131, 93, 21);
		panel.add(lblCinsiyet);

		JLabel lblTelefon = new JLabel("Telefon: ");
		lblTelefon.setFont(new Font("Arial Black", Font.PLAIN, 12));
		lblTelefon.setBounds(10, 175, 93, 21);
		panel.add(lblTelefon);

		JLabel lblDoumTarihi = new JLabel("Plaka no:");
		lblDoumTarihi.setFont(new Font("Arial Black", Font.PLAIN, 12));
		lblDoumTarihi.setBounds(10, 217, 93, 21);
		panel.add(lblDoumTarihi);

		JLabel lblGrevi = new JLabel("Marka:");
		lblGrevi.setFont(new Font("Arial Black", Font.PLAIN, 12));
		lblGrevi.setBounds(10, 269, 68, 21);
		panel.add(lblGrevi);

		JLabel lblifre = new JLabel("Model:");
		lblifre.setFont(new Font("Arial Black", Font.PLAIN, 12));
		lblifre.setBounds(10, 312, 93, 21);
		panel.add(lblifre);

		JLabel lblRenk = new JLabel("Renk:");
		lblRenk.setFont(new Font("Arial Black", Font.PLAIN, 12));
		lblRenk.setBounds(10, 352, 93, 21);
		panel.add(lblRenk);

		JButton btnNewButton_1 = new JButton("G\u00FCncelle");
		btnNewButton_1.setBackground(Color.WHITE);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				if (tcno1.getText().length() == 0 || ad1.getText().length() == 0 || soyad1.getText().length() == 0
						|| cep1.getText().length() == 0 || plaka1.getText().length() == 0
						|| marka1.getText().length() == 0 || model1.getText().length() == 0
						|| renk1.getText().length() == 0) {
					Helper.showMsg("fill");
				} else {
					boolean control = mgi.add(tcno1.getText(), ad1.getText(), soyad1.getText(), cep1.getText(),
							plaka1.getText(), marka1.getText(), model1.getText(), renk1.getText());
					if (control) {
						Helper.showMsg("success");
						tcno1.setText(null);
						ad1.setText(null);
						soyad1.setText(null);
						cep1.setText(null);
						plaka1.setText(null);
						marka1.setText(null);
						model1.setText(null);
						renk1.setText(null);

						// personelModel();

					}
				}
			}
		});
		btnNewButton_1.setBounds(227, 430, 130, 23);
		panel.add(btnNewButton_1);
       ArrayList<String> plakalar=new ArrayList<>();
for(int i=0; i<Odev2.m�steri.getList().size(); i++) {
	plakalar.add(Odev2.m�steri.getList().get(i).getPlakano());
}
		JButton btnNewButton_2 = new JButton("Arac\u0131m Nerde ?");
		
		btnNewButton_2.addActionListener(new ActionListener() {
		
			
			public void actionPerformed(ActionEvent e) {
				 int index=0;
					for(int i=0; i<plakalar.size(); i++) {
						if(plakalar.get(i).equals(plaka1.getText())){
						//	System.out.println(plakalar.get(i));
			            	index=i;
			            	//System.out.println(index);
			            }
						
					}
				
                if(plakalar.contains(plaka1.getText())){
                	String msg="Arac�n�z "+ Odev2.m�steri.getList().get(index).getKonum() + " Konumundad�r.";
                	JOptionPane.showMessageDialog(null, msg, "Mesaj", JOptionPane.INFORMATION_MESSAGE);
                	//System.out.println(Odev2.m�steri.getList().get(index).getKonum());
                }
                else {
                	String msg="Arac�n�z Bulunamad�.";
                	JOptionPane.showMessageDialog(null, msg, "Mesaj", JOptionPane.INFORMATION_MESSAGE);
                }
			
			}
		});
		btnNewButton_2.setBackground(Color.WHITE);
		btnNewButton_2.setBounds(227, 475, 130, 23);
		panel.add(btnNewButton_2);

		model1 = new JTextField();
		model1.setBounds(135, 313, 222, 25);
		panel.add(model1);
		model1.setColumns(10);

		renk1 = new JTextField();
		renk1.setColumns(10);
		renk1.setBounds(135, 353, 222, 25);
		panel.add(renk1);

		JButton btnSil = new JButton("\u00C7\u0131k\u0131\u015F");
		btnSil.setBackground(Color.WHITE);
		btnSil.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnSil.setForeground(Color.ORANGE);
		btnSil.setFont(new Font("Arial Black", Font.PLAIN, 15));
		btnSil.setBounds(397, 32, 136, 45);
		contentPane.add(btnSil);
	}
}
