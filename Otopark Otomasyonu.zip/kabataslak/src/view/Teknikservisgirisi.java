package view;


import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import model1.Personel1;
import model1.Teknikservis;

import javax.swing.JTextField;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Teknikservisgirisi extends JFrame {

	private JPanel contentPane;
	private JTextField txtTeknikServisGirii;
	static Teknikservis ts=new Teknikservis();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Teknikservisgirisi frame = new Teknikservisgirisi(ts);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Teknikservisgirisi(Teknikservis ts) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 697, 669);
		contentPane = new JPanel();
		contentPane.setBackground(Color.CYAN);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		txtTeknikServisGirii = new JTextField();
		txtTeknikServisGirii.setBackground(Color.WHITE);
		txtTeknikServisGirii.setEditable(false);
		txtTeknikServisGirii.setForeground(Color.PINK);
		txtTeknikServisGirii.setFont(new Font("Arial Black", Font.PLAIN, 30));
		txtTeknikServisGirii.setText("TEKN\u0130K SERV\u0130S G\u0130R\u0130\u015E\u0130");
		txtTeknikServisGirii.setBounds(118, 39, 397, 250);
		contentPane.add(txtTeknikServisGirii);
		txtTeknikServisGirii.setColumns(10);
		
		JButton btnNewButton = new JButton("Personel \u0130\u015Flemleri");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Personel.main(null);
				dispose();
			}
		});
		btnNewButton.setBackground(Color.WHITE);
		btnNewButton.setForeground(Color.MAGENTA);
		btnNewButton.setFont(new Font("Arial Black", Font.PLAIN, 17));
		btnNewButton.setBounds(52, 349, 224, 123);
		contentPane.add(btnNewButton);
		
		JButton btnSatIlemleri = new JButton("Sat\u0131\u015F \u0130\u015Flemleri");
		btnSatIlemleri.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Satis.main(null);
				dispose();
			}
		});
		btnSatIlemleri.setBackground(Color.WHITE);
		btnSatIlemleri.setForeground(Color.MAGENTA);
		btnSatIlemleri.setFont(new Font("Arial Black", Font.PLAIN, 17));
		btnSatIlemleri.setBounds(378, 349, 224, 123);
		contentPane.add(btnSatIlemleri);
	}
}
