package view;

import java.awt.BorderLayout;



import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableModel;

import helper.DBConnection;
import helper.Helper;
import model1.Personel�slemleri;

import javax.swing.JTextField;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JPasswordField;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JList;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JLayeredPane;
import javax.swing.JTable;


public class Personel extends JFrame {

	private JPanel absoukt;
	private JTextField txtPersonelBilgileri;
	private JTextField tcno1;
	private JTextField adSoyad1;
	private JTextField cinsiyet1;
	private JTextField telefon1;
	private JTextField dt1;
	private JTextField gorev1;
	private JLabel lblCinsiyet;
	private JLabel lblTelefon;
	private JLabel lblDoumTarihi;
	private JLabel lblGrevi;
	private JButton btnNewButton;
	private JButton btnSil;
	private JButton btnEkle;
	private JLabel lblSilmeVeGncelleme;
	private JScrollPane scrollPane;
	private DBConnection conn = new DBConnection();
	static Personel�slemleri personel = new Personel�slemleri();
	private DefaultTableModel teknikModel = null;
	private Object[] teknikData = null;
	private JTextField denemevs;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Personel frame = new Personel();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Personel() {
		teknikModel = new DefaultTableModel();
		Object[] colTeknikName = new Object[6];
		colTeknikName[0] = "tcno";
		colTeknikName[1] = "cinsiyet";
		colTeknikName[2] = "adSoyad";
		colTeknikName[3] = "telefon";
		colTeknikName[4] = "dogumtarihi";
		colTeknikName[5] = "gorevi";
		teknikModel.setColumnIdentifiers(colTeknikName);
		teknikData = new Object[6];
		for (int i = 0; i < personel.getList().size(); i++) {
			teknikData[0] = personel.getList().get(i).getTcno();
			teknikData[1] = personel.getList().get(i).getCinsiyet();
			teknikData[2] = personel.getList().get(i).getAdSoyad();
			teknikData[3] = personel.getList().get(i).getTelefon();
			teknikData[4] = personel.getList().get(i).getDogumtarihi();
			teknikData[5] = personel.getList().get(i).getGorevi();
			teknikModel.addRow(teknikData);
		}

		setTitle("Personel \u0130\u015Flemleri");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 690, 700);
		absoukt = new JPanel();
		absoukt.setBackground(Color.MAGENTA);
		absoukt.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(absoukt);
		absoukt.setLayout(null);

		JPanel panel = new JPanel();
		panel.setBackground(Color.CYAN);
		panel.setForeground(new Color(0, 0, 0));
		panel.setToolTipText("");
		panel.setBounds(0, 10, 387, 391);
		absoukt.add(panel);
		panel.setLayout(null);

		txtPersonelBilgileri = new JTextField();
		txtPersonelBilgileri.setForeground(Color.BLUE);
		txtPersonelBilgileri.setEditable(false);
		txtPersonelBilgileri.setFont(new Font("Arial Black", Font.PLAIN, 18));
		txtPersonelBilgileri.setText("Personel Bilgileri");
		txtPersonelBilgileri.setBounds(10, 5, 267, 32);
		panel.add(txtPersonelBilgileri);
		txtPersonelBilgileri.setColumns(10);

		tcno1 = new JTextField();
		tcno1.setBounds(135, 47, 222, 25);
		panel.add(tcno1);
		tcno1.setColumns(10);

		adSoyad1 = new JTextField();
		adSoyad1.setColumns(10);
		adSoyad1.setBounds(135, 90, 222, 25);
		panel.add(adSoyad1);

		cinsiyet1 = new JTextField();
		cinsiyet1.setColumns(10);
		cinsiyet1.setBounds(135, 131, 222, 25);
		panel.add(cinsiyet1);

		telefon1 = new JTextField();
		telefon1.setColumns(10);
		telefon1.setBounds(135, 175, 222, 25);
		panel.add(telefon1);

		dt1 = new JTextField();
		dt1.setColumns(10);
		dt1.setBounds(135, 217, 222, 25);
		panel.add(dt1);

		gorev1 = new JTextField();
		gorev1.setColumns(10);
		gorev1.setBounds(135, 263, 222, 25);
		panel.add(gorev1);

		JLabel lblNewLabel = new JLabel("TC:");
		lblNewLabel.setFont(new Font("Arial Black", Font.PLAIN, 12));
		lblNewLabel.setBounds(10, 47, 93, 21);
		panel.add(lblNewLabel);

		JLabel lblAdVeSoyad = new JLabel("Ad\u0131 ve Soyad\u0131");
		lblAdVeSoyad.setFont(new Font("Arial Black", Font.PLAIN, 12));
		lblAdVeSoyad.setBounds(10, 94, 93, 21);
		panel.add(lblAdVeSoyad);

		lblCinsiyet = new JLabel("Cinsiyet: ");
		lblCinsiyet.setFont(new Font("Arial Black", Font.PLAIN, 12));
		lblCinsiyet.setBounds(10, 131, 93, 21);
		panel.add(lblCinsiyet);

		lblTelefon = new JLabel("Telefon: ");
		lblTelefon.setFont(new Font("Arial Black", Font.PLAIN, 12));
		lblTelefon.setBounds(10, 175, 93, 21);
		panel.add(lblTelefon);

		lblDoumTarihi = new JLabel("Do\u011Fum Tarihi:");
		lblDoumTarihi.setFont(new Font("Arial Black", Font.PLAIN, 12));
		lblDoumTarihi.setBounds(10, 217, 93, 21);
		panel.add(lblDoumTarihi);

		lblGrevi = new JLabel("G\u00F6revi: ");
		lblGrevi.setFont(new Font("Arial Black", Font.PLAIN, 12));
		lblGrevi.setBounds(10, 269, 93, 21);
		panel.add(lblGrevi);

		btnNewButton = new JButton("Anasayfa");
		btnNewButton.setBackground(Color.WHITE);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Teknikservisgirisi.main(null);
				dispose();
			}
		});
		btnNewButton.setForeground(Color.ORANGE);
		btnNewButton.setFont(new Font("Arial Black", Font.PLAIN, 15));
		btnNewButton.setBounds(446, 50, 136, 45);
		absoukt.add(btnNewButton);

		btnSil = new JButton("Sil");
		btnSil.setBackground(Color.WHITE);
		btnSil.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (Helper.confirm("sure")) {
					Boolean control = personel.delete(denemevs.getText());
					if (control) {
						Helper.showMsg("success");
						denemevs.setText(null);
						teknikModel();
					}

				}
			}
		});
		btnSil.setForeground(Color.ORANGE);
		btnSil.setFont(new Font("Arial Black", Font.PLAIN, 15));
		btnSil.setBounds(446, 188, 136, 45);
		absoukt.add(btnSil);

		btnEkle = new JButton("Ekle");
		btnEkle.setBackground(Color.WHITE);
		btnEkle.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (tcno1.getText().length() == 0 || adSoyad1.getText().length() == 0
						|| cinsiyet1.getText().length() == 0 || telefon1.getText().length() == 0
						|| dt1.getText().length() == 0 || gorev1.getText().length() == 0) {
					Helper.showMsg("fill");
				} else {
					boolean control = personel.add(tcno1.getText(), adSoyad1.getText(), cinsiyet1.getText(),
							telefon1.getText(), dt1.getText(), gorev1.getText());
					if (control) {
						Helper.showMsg("success");
						tcno1.setText(null);
						adSoyad1.setText(null);
						cinsiyet1.setText(null);
						telefon1.setText(null);
						dt1.setText(null);
						gorev1.setText(null);
						teknikModel();

					}

				}
			}
		});

		btnEkle.setForeground(Color.ORANGE);
		btnEkle.setFont(new Font("Arial Black", Font.PLAIN, 15));
		btnEkle.setBounds(446, 251, 136, 45);
		absoukt.add(btnEkle);

		lblSilmeVeGncelleme = new JLabel("Silme ve g\u00FCncelleme i\u00E7in alttan veri se\u00E7in.");
		lblSilmeVeGncelleme.setFont(new Font("Arial Black", Font.PLAIN, 12));
		lblSilmeVeGncelleme.setBounds(10, 467, 371, 21);
		absoukt.add(lblSilmeVeGncelleme);
		

		scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 495, 640, 178);
		absoukt.add(scrollPane);

		table = new JTable(teknikModel);
		table.setBackground(Color.WHITE);
		scrollPane.setViewportView(table);
		table.getModel().addTableModelListener(new TableModelListener() {

			@Override
			public void tableChanged(TableModelEvent e) {
				// TODO Auto-generated method stub
				if (e.getType() == TableModelEvent.UPDATE) {
					String selectTcno = table.getValueAt(table.getSelectedRow(), 0).toString();
					String selectadSoyad = table.getValueAt(table.getSelectedRow(), 1).toString();
					String selectCinsiyet = table.getValueAt(table.getSelectedRow(), 2).toString();
					String selectTelefon = table.getValueAt(table.getSelectedRow(), 3).toString();
					String selectdogumtarihi = table.getValueAt(table.getSelectedRow(), 4).toString();
					String selectgorevi = table.getValueAt(table.getSelectedRow(), 5).toString();

					boolean control = personel.update(selectTcno, selectadSoyad, selectCinsiyet, selectTelefon,
							selectdogumtarihi, selectgorevi);
					if (control) {
						Helper.showMsg("success");
						teknikModel();
					}

				}
			}
		});
		JLabel lblNewLabel_2 = new JLabel("Personel tc");
		lblNewLabel_2.setFont(new Font("Arial Black", Font.PLAIN, 18));
		lblNewLabel_2.setBounds(446, 105, 136, 31);
		absoukt.add(lblNewLabel_2);

		denemevs = new JTextField();
		denemevs.setEditable(false);
		denemevs.setBounds(446, 146, 136, 32);
		absoukt.add(denemevs);
		denemevs.setColumns(10);
		table.getSelectionModel().addListSelectionListener(new ListSelectionListener() {

			@Override
			public void valueChanged(ListSelectionEvent e) {
				try {
					denemevs.setText(table.getValueAt(table.getSelectedRow(), 0).toString());

				} catch (Exception ex) {

				}

			}
		});
	}

	public void teknikModel() {
		DefaultTableModel clearModel = (DefaultTableModel) table.getModel();
		clearModel.setRowCount(0);
		for (int i = 0; i < personel.getList().size(); i++) {
			teknikData[0] = personel.getList().get(i).getTcno();
			teknikData[1] = personel.getList().get(i).getAdSoyad();
			teknikData[2] = personel.getList().get(i).getCinsiyet();
			teknikData[3] = personel.getList().get(i).getTelefon();
			teknikData[4] = personel.getList().get(i).getDogumtarihi();
			teknikData[5] = personel.getList().get(i).getGorevi();
			teknikModel.addRow(teknikData);
		}
	}
}
