package view;

import java.awt.BorderLayout;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableModel;

import helper.DBConnection;
import helper.Helper;
import model1.*;

import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Color;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class Satis extends JFrame {
	private DBConnection conn = new DBConnection();
	private JPanel contentPane;
	private JTextField plaka;
	private JTextField giris;
	private JTextField cikis;
	private JTextField �cret;
	private JTextField tutar1;
	static Satis1 satis = new Satis1();
	Statement st = null;
	ResultSet rs = null;
	private DefaultTableModel teknikModel1 = null;
	private Object[] teknikData1 = null;

	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Satis frame = new Satis();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Satis() {

		teknikModel1 = new DefaultTableModel();
		Object[] colpersonelName1 = new Object[4];
		colpersonelName1[0] = "plaka";
		colpersonelName1[1] = "giris";
		colpersonelName1[2] = "cikis";
		colpersonelName1[3] = "�cret";
		teknikModel1.setColumnIdentifiers(colpersonelName1);
		teknikData1 = new Object[4];
		for (int i = 0; i < satis.getList().size(); i++) {
			teknikData1[0] = satis.getList().get(i).getPlaka();
			teknikData1[1] = satis.getList().get(i).getGiris();
			teknikData1[2] = satis.getList().get(i).getCikis();
			teknikData1[3] = satis.getList().get(i).get�cret();
			teknikModel1.addRow(teknikData1);
		}
		setTitle("Sat\u0131\u015F \u0130\u015Flemleri");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 690, 684);
		contentPane = new JPanel();
		contentPane.setBackground(Color.CYAN);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblNewLabel = new JLabel("Plaka: ");
		lblNewLabel.setFont(new Font("Arial Black", Font.PLAIN, 12));
		lblNewLabel.setBounds(22, 39, 89, 34);
		contentPane.add(lblNewLabel);

		JLabel lblGiriTarihi = new JLabel("Giri\u015F saati:");
		lblGiriTarihi.setFont(new Font("Arial Black", Font.PLAIN, 12));
		lblGiriTarihi.setBounds(22, 83, 89, 34);
		contentPane.add(lblGiriTarihi);

		JLabel lblkTarihi = new JLabel("\u00C7\u0131k\u0131\u015F saati:");
		lblkTarihi.setFont(new Font("Arial Black", Font.PLAIN, 12));
		lblkTarihi.setBounds(22, 127, 89, 34);
		contentPane.add(lblkTarihi);

		JLabel lblSaatcreti = new JLabel("Saat \u00DCcreti: ");
		lblSaatcreti.setFont(new Font("Arial Black", Font.PLAIN, 12));
		lblSaatcreti.setBounds(22, 171, 89, 34);
		contentPane.add(lblSaatcreti);

		JLabel lbldenecekTutar = new JLabel("\u00D6denecek Tutar:");
		lbldenecekTutar.setFont(new Font("Arial Black", Font.PLAIN, 12));
		lbldenecekTutar.setBounds(22, 215, 110, 34);
		contentPane.add(lbldenecekTutar);

		plaka = new JTextField();
		plaka.setBounds(147, 39, 171, 28);
		contentPane.add(plaka);
		plaka.setColumns(10);

		giris = new JTextField();
		giris.setColumns(10);
		giris.setBounds(147, 83, 171, 28);
		contentPane.add(giris);

		cikis = new JTextField();
		cikis.setColumns(10);
		cikis.setBounds(147, 136, 171, 28);
		contentPane.add(cikis);

		�cret = new JTextField();
		�cret.setColumns(10);
		�cret.setBounds(147, 180, 171, 28);
		contentPane.add(�cret);

		tutar1 = new JTextField();
		tutar1.setColumns(10);
		tutar1.setBounds(147, 224, 171, 28);
		contentPane.add(tutar1);

		JLabel lblNewLabel_1 = new JLabel("TL");
		lblNewLabel_1.setFont(new Font("Arial Black", Font.PLAIN, 14));
		lblNewLabel_1.setBounds(328, 180, 45, 25);
		contentPane.add(lblNewLabel_1);

		JLabel lblNewLabel_1_1 = new JLabel("TL");
		lblNewLabel_1_1.setFont(new Font("Arial Black", Font.PLAIN, 14));
		lblNewLabel_1_1.setBounds(328, 227, 45, 25);
		contentPane.add(lblNewLabel_1_1);

	

		JButton btnFiyatlandr = new JButton("Kaydet");
		btnFiyatlandr.setBackground(Color.WHITE);
		btnFiyatlandr.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (plaka.getText().length() == 0 || giris.getText().length() == 0 || cikis.getText().length() == 0
						|| �cret.getText().length() == 0) {
					Helper.showMsg("fill");
				} else {
					int selectGiris = Integer.parseInt(giris.getText());
					int selectCikis = Integer.parseInt(cikis.getText());
					int select�cret = Integer.parseInt(tutar1.getText());
					boolean control = satis.add(plaka.getText(), selectGiris, selectCikis, select�cret);
					if (control) {
						Helper.showMsg("success");

						plaka.setText(null);
						giris.setText(null);
						cikis.setText(null);
						tutar1.setText(null);
						SatisModel();

					}
				}
			}
		});
		btnFiyatlandr.setForeground(Color.ORANGE);
		btnFiyatlandr.setFont(new Font("Arial Black", Font.PLAIN, 17));
		btnFiyatlandr.setBounds(373, 193, 145, 41);
		contentPane.add(btnFiyatlandr);

		JButton btnNewButton_1 = new JButton("Anasayfa");
		btnNewButton_1.setBackground(Color.WHITE);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Teknikservisgirisi.main(null);
				dispose();
			}
		});
		btnNewButton_1.setForeground(Color.MAGENTA);
		btnNewButton_1.setFont(new Font("Arial Black", Font.PLAIN, 18));
		btnNewButton_1.setBounds(524, 10, 126, 63);
		contentPane.add(btnNewButton_1);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 263, 640, 371);
		contentPane.add(scrollPane);

		table = new JTable(teknikModel1);
		table.setBackground(Color.WHITE);
		scrollPane.setViewportView(table);
		
		table.getModel().addTableModelListener(new TableModelListener() {

			@Override
			public void tableChanged(TableModelEvent e) {
				// TODO Auto-generated method stub
				if (e.getType() == TableModelEvent.UPDATE) {
					String selectPlaka = table.getValueAt(table.getSelectedRow(), 0).toString();
					int selectGiris = Integer.parseInt(table.getValueAt(table.getSelectedRow(),1).toString());
					int select��k�� = Integer.parseInt(table.getValueAt(table.getSelectedRow(),2).toString());
					int select�cret = Integer.parseInt(table.getValueAt(table.getSelectedRow(),3).toString());

					boolean control = satis.update(selectPlaka, selectGiris, select��k��, select�cret);
					if (control) {
						Helper.showMsg("success");
						SatisModel();
					}

				}
			}
		});
		JButton btnNewButton = new JButton("Hesapla");
		btnNewButton.setBackground(Color.WHITE);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int ifade=Integer.parseInt(giris.getText());
				int ifade1=Integer.parseInt(cikis.getText());
				int ifade2=Integer.parseInt(�cret.getText());
                  int tutar=(ifade-ifade1)*ifade2;
                   String a=String.valueOf(tutar);
                   satis.setTutar(tutar);
                  tutar1.setText(a);	
                  
                  }
		});
		btnNewButton.setForeground(Color.ORANGE);
		btnNewButton.setFont(new Font("Arial Black", Font.PLAIN, 17));
		btnNewButton.setBounds(373, 122, 145, 41);
		contentPane.add(btnNewButton);
	}

	public void SatisModel() {
		DefaultTableModel clearModel = (DefaultTableModel) table.getModel();
		clearModel.setRowCount(0);
		for (int i = 0; i < satis.getList().size(); i++) {
			teknikData1[0] = satis.getList().get(i).getPlaka();
			teknikData1[1] = satis.getList().get(i).getGiris();
			teknikData1[2] = satis.getList().get(i).getCikis();
			teknikData1[3] = satis.getList().get(i).get�cret();
			teknikModel1.addRow(teknikData1);
		}
	}
}
