package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.JMenuBar;
import javax.swing.JScrollPane;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import java.awt.Color;

public class Odev4 extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Odev4 frame = new Odev4();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Odev4() {
		ArrayList<String> alanlar = new ArrayList<String>();
		alanlar.add("A1");
		alanlar.add("A2");
		alanlar.add("A3");
		alanlar.add("A4");
		alanlar.add("A5");
		alanlar.add("B1");
		alanlar.add("B2");
		alanlar.add("B3");
		alanlar.add("B4");
		alanlar.add("B5");
		alanlar.add("C1");
		alanlar.add("C2");
		alanlar.add("C3");
		alanlar.add("C4");
		alanlar.add("C5");
		alanlar.add("D1");
		alanlar.add("D2");
		alanlar.add("D3");
		alanlar.add("D4");
		alanlar.add("D5");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1000, 711);
		contentPane = new JPanel();
		contentPane.setBackground(Color.GREEN);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JButton a5 = new JButton("A5");
		a5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		a5.setBounds(10, 11, 105, 85);
		contentPane.add(a5);

		JButton a4 = new JButton("A4");
		a4.setBounds(135, 11, 105, 85);
		contentPane.add(a4);

		JButton a3 = new JButton("A3");
		a3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		a3.setBounds(260, 11, 105, 85);
		contentPane.add(a3);

		JButton a2 = new JButton("A2");
		a2.setBounds(375, 11, 105, 85);
		contentPane.add(a2);

		JButton a1 = new JButton("A1");
		a1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		a1.setBounds(501, 11, 105, 85);
		contentPane.add(a1);

		JButton btnNewButton_5_5 = new JButton("Men\u00FC");
		btnNewButton_5_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Odev1.main(null);
				dispose();
			}
		});
		btnNewButton_5_5.setBounds(585, 257, 149, 85);
		contentPane.add(btnNewButton_5_5);

		JButton b5 = new JButton("B5");
		b5.setBounds(10, 117, 105, 85);
		contentPane.add(b5);

		JButton b4 = new JButton("B4");
		b4.setBounds(135, 117, 105, 85);
		contentPane.add(b4);

		JButton b3 = new JButton("B3");
		b3.setBounds(260, 117, 105, 85);
		contentPane.add(b3);

		JButton b2 = new JButton("B2");
		b2.setBounds(375, 117, 105, 85);
		contentPane.add(b2);

		JButton b1 = new JButton("B1");
		b1.setBounds(501, 117, 105, 85);
		contentPane.add(b1);

		JButton btnNewButton_5_7_4 = new JButton("Programdan \u00C7\u0131k");
		btnNewButton_5_7_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnNewButton_5_7_4.setBounds(585, 366, 149, 85);
		contentPane.add(btnNewButton_5_7_4);

		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\mehme\\Desktop\\0dc9c122bd9c5c9551d611bbc3e84716d040bef8.jpg"));
		lblNewLabel.setBounds(249, 238, 136, 231);
		contentPane.add(lblNewLabel);

		JButton d5 = new JButton("D5");
		d5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		d5.setBounds(22, 480, 105, 85);
		contentPane.add(d5);

		JButton d4 = new JButton("D4");
		d4.setBounds(147, 480, 105, 85);
		contentPane.add(d4);

		JButton d3 = new JButton("D3");
		d3.setBounds(272, 480, 105, 85);
		contentPane.add(d3);

		JButton d2 = new JButton("D2");
		d2.setBounds(387, 480, 105, 85);
		contentPane.add(d2);

		JButton d1 = new JButton("D1");
		d1.setBounds(513, 480, 105, 85);
		contentPane.add(d1);

		JButton c1 = new JButton("C1");
		c1.setBounds(513, 586, 105, 85);
		contentPane.add(c1);

		JButton c2 = new JButton("C2");
		c2.setBounds(387, 586, 105, 85);
		contentPane.add(c2);

		JButton c3 = new JButton("C3");
		c3.setBounds(272, 586, 105, 85);
		contentPane.add(c3);

		JButton c4 = new JButton("C4");
		c4.setBounds(147, 586, 105, 85);
		contentPane.add(c4);

		JButton c5 = new JButton("C5");
		c5.setBounds(22, 586, 105, 85);
		contentPane.add(c5);
		ArrayList<String> konumlar = new ArrayList<String>();
		for (int i = 0; i < Odev2.m�steri.getList().size(); i++) {
			konumlar.add(Odev2.m�steri.getList().get(i).getKonum());

		}
		for (int i = 0; i < konumlar.size(); i++) {
			// System.out.println(konumlar.get(i));
			if (alanlar.contains(konumlar.get(i))) {
				if (a1.getText().equals(konumlar.get(i))) {
					a1.setText(Odev2.m�steri.getList().get(i).getPlakano());
					System.out.println(Odev2.m�steri.getList().get(i).getPlakano());
					a1.setBackground(Color.RED);
				}
				if (a2.getText().equals(konumlar.get(i))) {
					a2.setText(Odev2.m�steri.getList().get(i).getPlakano());
					System.out.println(Odev2.m�steri.getList().get(i).getPlakano());
					a2.setBackground(Color.RED);
				}
				if (a3.getText().equals(konumlar.get(i))) {
					a3.setText(Odev2.m�steri.getList().get(i).getPlakano());
					System.out.println(Odev2.m�steri.getList().get(i).getPlakano());
					a3.setBackground(Color.RED);
				}
				if (a4.getText().equals(konumlar.get(i))) {
					a4.setText(Odev2.m�steri.getList().get(i).getPlakano());
					System.out.println(Odev2.m�steri.getList().get(i).getPlakano());
					a4.setBackground(Color.RED);
				}
				if (a5.getText().equals(konumlar.get(i))) {
					a5.setText(Odev2.m�steri.getList().get(i).getPlakano());
					System.out.println(Odev2.m�steri.getList().get(i).getPlakano());
					a5.setBackground(Color.RED);
				}
				if (b1.getText().equals(konumlar.get(i))) {
					b1.setText(Odev2.m�steri.getList().get(i).getPlakano());
					System.out.println(Odev2.m�steri.getList().get(i).getPlakano());
					b1.setBackground(Color.RED);
				}
				if (b2.getText().equals(konumlar.get(i))) {
					b2.setText(Odev2.m�steri.getList().get(i).getPlakano());
					System.out.println(Odev2.m�steri.getList().get(i).getPlakano());
					b2.setBackground(Color.RED);
				}
				if (b3.getText().equals(konumlar.get(i))) {
					b3.setText(Odev2.m�steri.getList().get(i).getPlakano());
					System.out.println(Odev2.m�steri.getList().get(i).getPlakano());
					b3.setBackground(Color.RED);
				}
				if (b4.getText().equals(konumlar.get(i))) {
					b4.setText(Odev2.m�steri.getList().get(i).getPlakano());
					System.out.println(Odev2.m�steri.getList().get(i).getPlakano());
					b4.setBackground(Color.RED);
				}
				if (b5.getText().equals(konumlar.get(i))) {
					b5.setText(Odev2.m�steri.getList().get(i).getPlakano());
					System.out.println(Odev2.m�steri.getList().get(i).getPlakano());
					b5.setBackground(Color.RED);
				}
				if (c1.getText().equals(konumlar.get(i))) {
					c1.setText(Odev2.m�steri.getList().get(i).getPlakano());
					System.out.println(Odev2.m�steri.getList().get(i).getPlakano());
					c1.setBackground(Color.RED);
				}
				if (c2.getText().equals(konumlar.get(i))) {
					c2.setText(Odev2.m�steri.getList().get(i).getPlakano());
					System.out.println(Odev2.m�steri.getList().get(i).getPlakano());
					c2.setBackground(Color.RED);
				}
				if (c3.getText().equals(konumlar.get(i))) {
					c3.setText(Odev2.m�steri.getList().get(i).getPlakano());
					System.out.println(Odev2.m�steri.getList().get(i).getPlakano());
					c3.setBackground(Color.RED);
				}
				if (c4.getText().equals(konumlar.get(i))) {
					c4.setText(Odev2.m�steri.getList().get(i).getPlakano());
					System.out.println(Odev2.m�steri.getList().get(i).getPlakano());
					c4.setBackground(Color.RED);
				}
				if (c5.getText().equals(konumlar.get(i))) {
					c5.setText(Odev2.m�steri.getList().get(i).getPlakano());
					System.out.println(Odev2.m�steri.getList().get(i).getPlakano());
					c5.setBackground(Color.RED);
				}
				if (d1.getText().equals(konumlar.get(i))) {
					d1.setText(Odev2.m�steri.getList().get(i).getPlakano());
					System.out.println(Odev2.m�steri.getList().get(i).getPlakano());
					d1.setBackground(Color.RED);
				}
				if (d2.getText().equals(konumlar.get(i))) {
					d2.setText(Odev2.m�steri.getList().get(i).getPlakano());
					System.out.println(Odev2.m�steri.getList().get(i).getPlakano());
					d2.setBackground(Color.RED);
				}
				if (d3.getText().equals(konumlar.get(i))) {
					d3.setText(Odev2.m�steri.getList().get(i).getPlakano());
					System.out.println(Odev2.m�steri.getList().get(i).getPlakano());
					d3.setBackground(Color.RED);
				}
				if (d4.getText().equals(konumlar.get(i))) {
					d4.setText(Odev2.m�steri.getList().get(i).getPlakano());
					System.out.println(Odev2.m�steri.getList().get(i).getPlakano());
					d4.setBackground(Color.RED);
				}
				if (d5.getText().equals(konumlar.get(i))) {
					d5.setText(Odev2.m�steri.getList().get(i).getPlakano());
					System.out.println(Odev2.m�steri.getList().get(i).getPlakano());
					d5.setBackground(Color.RED);
				}

			}

		}

	}
}
