package view;

import java.awt.BorderLayout;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import model1.Personel1;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.JMenuBar;
import javax.swing.JLabel;
import javax.swing.JTable;

public class Odev1 extends JFrame {

	private JPanel contentPane;

	static Personel1 as=new Personel1();
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Odev1 frame = new Odev1(as);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Odev1(Personel1 as) {
		setTitle("Personel Men\u00FC");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 720, 478);
		contentPane = new JPanel();
		contentPane.setBackground(Color.CYAN);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton = new JButton("M\u00FC\u015Fteri Giri\u015Fi");
		btnNewButton.setBackground(Color.WHITE);
		btnNewButton.setFont(new Font("Arial Black", Font.PLAIN, 18));
		btnNewButton.setForeground(Color.MAGENTA);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Odev2.main(null);
				dispose();
			}
		});
		btnNewButton.setBounds(20, 249, 216, 66);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1_1 = new JButton("Ara\u00E7 Konumu");
		btnNewButton_1_1.setBackground(Color.WHITE);
		btnNewButton_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Odev4.main(null);
				dispose();
			}
		});
		btnNewButton_1_1.setForeground(Color.MAGENTA);
		btnNewButton_1_1.setFont(new Font("Arial Black", Font.PLAIN, 18));
		btnNewButton_1_1.setBounds(264, 249, 199, 66);
		contentPane.add(btnNewButton_1_1);
		
		JButton btnNewButton_1_1_1 = new JButton("Ara\u00E7 \u00E7\u0131k\u0131\u015F\u0131");
		btnNewButton_1_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			AracCikis.main(null);
			dispose();
			}
		});
		btnNewButton_1_1_1.setBackground(Color.WHITE);
		btnNewButton_1_1_1.setFont(new Font("Arial Black", Font.PLAIN, 18));
		btnNewButton_1_1_1.setForeground(Color.MAGENTA);
		btnNewButton_1_1_1.setBounds(502, 249, 174, 66);
		contentPane.add(btnNewButton_1_1_1);
		
		JLabel lblNewLabel = new JLabel("Personel Men\u00FC");
		lblNewLabel.setForeground(Color.PINK);
		lblNewLabel.setFont(new Font("Arial Black", Font.PLAIN, 30));
		lblNewLabel.setBounds(218, 53, 269, 132);
		contentPane.add(lblNewLabel);
	}
}
